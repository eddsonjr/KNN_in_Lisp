'''
	Este arquivo contem as funcoes necessarias para a leitura e escrita de arquivos
	csv

	Edson Jr
	27/04/2017
'''

import os
import csv
import sys
import smartphone 
import listOfSmartphones


#Esta funcao e responsavel por abrir arquivos em disco
def openFile(path):
	try:
		with open(path,'r') as file:
			loadCSVData(file)
	except IOError:
		print "Error: File not found!"
		print "Aborting..."
		sys.exit()


#Esta funcao e responsavel por carregar arquivos csv
def loadCSVData(file):
	id = 0
	reader = csv.reader(file)

	for row in reader:
		print row #imprime todas as linhas do arquivo csv como sendo uma lista
		id = id+1 #incrementando o id do smartphone
		sm = smartphone.SmartPhone(id,row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],None,None)
		listOfSmartphones.listOfsmartphones.append(sm)


	print "\n"
	file.close()


#Esta funca e responsavel por escrever arquivos no formato csv
#E necessario manipular quais campos serao colocados no arquivo
def createCSV(file):
	try:
		file = open(file,'w') #criando o arquivo em modo escrita

		#escrevendo no arquivo, linha por linha, com os dados da lista de celulares categorizados
		for i in listOfSmartphones.listOfSmartphonesCategorized:
			line = str(i.model)+','+str(i.maxSim)+','+str(i.maxMenInt)+','+str(i.qtCores)+','+str(i.clockProcessor)+','+str(i.ramMem)+','+str(i.display)+','+str(i.camPixel)+','+str(i.ratio)+','+str(i.category)+"\n"
			file.write(line)
			print line

	except IOError:
		print "Error: Impossible create a output file!"
		print "Aborting"
		sys.exit()

















