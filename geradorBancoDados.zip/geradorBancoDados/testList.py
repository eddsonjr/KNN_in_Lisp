import itertools

list13 = [1,2,3,4,5,6,7,8,9,10,11,12,13]
list5 = [1,2,3,4,5]
list10 = [1,2,3,4,5,6,7,8,9,10]


partition = len(list13)/3+1
print "Partition: " + str(partition)
listoflist13 = [list13[i:i+partition] for i in range(0,len(list13),partition)]
print listoflist13



partition = len(list5)/3+1
print "Partition: " + str(partition)
listoflist5 = [list5[i:i+partition] for i in range(0,len(list5),partition)]
print listoflist5


partition = len(list10)/3+1
print "Partition: " + str(partition)
listoflist10 = [list10[i:i+partition] for i in range(0,len(list10),partition)]
print listoflist10






