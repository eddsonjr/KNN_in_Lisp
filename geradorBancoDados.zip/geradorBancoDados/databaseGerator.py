'''
	Este script e responsavel por gerar os arquivos de banco de dados
	bem como as sua classificacao

	Edson Jr
	27/04/2017
'''


import file 
import listOfSmartphones

#abrindo o arquivo de banco de dados
file.openFile("./database.csv")

#calculando a distancia dos telefones da base de dados com o celular zero
listOfSmartphones.euclidianDistances((0,0,0,0,0,0,0))
#imprimindo lista de smartphones com o ratio (resultado comparativo entre os celulares com o celular zero)
#print "List of smartphones with ratio value. Not categorized and not sorted!"
#print listOfSmartphones.printListsOfSmartphones()

#ordendando os celulares com base no ratio ja calculado 
listOfSmartphones.sortByRatio()

#imprimindo a lista de smartphones com o ratio e ja ordenada
#print "List of smartphones with ratio value. Not categorized and sorted!"
#print listOfSmartphones.printListOfSmartphonesCategorized()


#categorizando os celulares
listOfSmartphones.categorize()

#imprimindo os celulares categorizados
print "Smartphones cateogrizeds"
listOfSmartphones.printListOfSmartphonesCategorized()


#criando o arquivo csv com os dados dos smartphones categorizados
print "Salvando arquivos..."
file.createCSV("database_classifield.csv")










