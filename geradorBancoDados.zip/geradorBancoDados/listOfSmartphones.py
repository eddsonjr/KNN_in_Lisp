'''
	Este arquivo contem definicoes de funcoes que manipulam a 
	lista de smartphones bem como os calculos necessarios para criar
	a classificacao da base de dados

	Edson Jr
	27/04/2017
'''

import sys
import smartphone
import math
from scipy.spatial import distance #responsavel por realizar calculos de distancias
import itertools

#variaveis globais
listOfsmartphones = [] #representa a lista que contem os smartphones vindos do arquivo csv
listOfSmartphonesCategorized = [] #representa a lista de smartphones ja categorizados

#Definindo um enum para categorizar os celulares
def enum(**enums):
    return type('Enum', (), enums)

#enum de categorias
categories = enum(TOP="TOP",MED="MEDIAN",BAD="BAD")


#Esta funcao serve para imprimir a lista de smartphones originais
def printListsOfSmartphones():
	if  listOfsmartphones:
		print "Size list [original list]: " + str(len(listOfsmartphones))
		for l in listOfsmartphones:
			print (l.printSmartPhoneInfos())
	else:
		print "listOfsmartphones is null"


#Esta funcao serve para imprimir a lista de smartphones categorizados
def printListOfSmartphonesCategorized():
	if  listOfSmartphonesCategorized:
		print "Size list [categorized]: " + str(len(listOfSmartphonesCategorized))
		for k in listOfSmartphonesCategorized:
			print (k.printSmartPhoneInfos())
	else:
		print "listOfSmartphonesCategorized is null"



#Esta funcao serve para calcular a distancia de dois pontos euclidiana
#usada para comparar cada smartphone da base de dados com o celular zero
def euclidianDistances(points):
	for l in listOfsmartphones:
		phoneAtributes = (float(l.maxSim),float(l.maxMenInt),float(l.qtCores),float(l.clockProcessor),float(l.ramMem),float(l.display),float(l.camPixel))
		ratio = distance.euclidean(phoneAtributes,points) #realizando a distancia euclidiana
		#ratio = round(ratio,2) #arredonda as casas decimais para 2
		l.ratio = ratio


#Esta funcao serve para ordenar a lista de smartphones baseadas no ratio calculado
def sortByRatio():
	global listOfSmartphonesCategorized 
	listOfSmartphonesCategorized = sorted(listOfsmartphones, key=lambda smartphone: smartphone.ratio,reverse = True)



#Esta funcao e responsavel por criar as definicoes das classes 
def categorize():
	global listOfSmartphonesCategorized
	separator = int(len(listOfSmartphonesCategorized)/3)+1
	#separando a lista de telefones a serem categorizados em 3 sublistas
	listOfLists = [listOfSmartphonesCategorized[i:i+separator] for i in range(0,len(listOfSmartphonesCategorized),separator)]
	
	#categorizando cada sublista criada
	interator(listOfLists[0],categories.TOP) #celulares bons
	interator(listOfLists[1],categories.MED) #celulares medianos
	interator(listOfLists[2],categories.BAD) #celulares ruins

	#jutando agora tudo em uma unica lista
	listOfSmartphonesCategorized = list(itertools.chain.from_iterable(listOfLists))




#interator para categorizar 
def interator(sublist,cat):
	for s in sublist:
		s.category = cat


	


























