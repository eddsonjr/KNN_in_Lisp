'''
	Esta classe representa cada telefone existente na base de
	dados. 

	Edson Jr
	27/04/2017
'''


class SmartPhone:

	def __init__(self,id,model, maxSim,maxMenInt,qtCores,clockProcessor,ramMem,display,camPixel,category,ratio):
		self.id = id
		self.model = model
		self.maxSim = maxSim
		self.maxMenInt = maxMenInt
		self.qtCores = qtCores
		self.clockProcessor = clockProcessor
		self.ramMem = ramMem
		self.display = display
		self.camPixel = camPixel
		self.category = category
		self.ratio = ratio


	def printSmartPhoneInfos(self):
		
		print "SmartPhone id: ", self.id 
		print "Model: " + self.model
		print "Sim card: " + self.maxSim
		print "Internal memory: " + self.maxMenInt
		print "Cores: " + self.qtCores
		print "Clock: " + self.clockProcessor
		print "RAM: " + self.ramMem
		print "Screen size: " + self.display
		print "Best camera pixel: " + self.camPixel

		#verificando a classificacao
		if self.category is None: 
			print ">>Smartphone not categorized!"
		else:
			print "Category: " + self.category

		#verificando o ratio
		if self.ratio is None:
			print ">>No ratio!"
		else:
			print "Ratio: " + str(self.ratio)

		print "\n"


 










